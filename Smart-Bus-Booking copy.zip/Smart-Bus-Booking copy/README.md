# SmartBus Ethiopia

Bus booking app for Addis Ababa, Ethiopia.

## Quick Start

### Backend

```bash
cd backend
uv sync

# Reset and setup
rm -f ../db/smartbus.db
uv run alembic upgrade head
uv run python -c "from app.seed_data import create_ethiopian_bus_data; create_ethiopian_bus_data()"

# Run
uv run uvicorn app.main:app --port 7077
```

### Frontend

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Open http://localhost:5173

## Credentials

- admin@smartbus.et / admin123
- demo@smartbus.com / demo123

## Folders

```
Smart-Bus-Booking/
├── backend/    # FastAPI
├── frontend/   # React
└── db/         # SQLite
```